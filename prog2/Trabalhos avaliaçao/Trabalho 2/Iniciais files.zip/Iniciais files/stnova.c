/*****************************************************************/
/*    Estrutura nova a implementar | PROG2 | MIEEC | 2020/21     */
/*****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stnova.h"

estrutura *st_nova()
{
    return NULL;
}

int st_importa_grafo(estrutura *st, grafo *g)
{
    return -1;
}

char *st_pesquisa(estrutura *st, char *origem, char *destino)
{
    return NULL;
}

int st_apaga(estrutura *st)
{
    return -1;
}
